package DAO;

import beans.Categoria;
import beans.Produto;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author mathe
 */
public class ProdutoDAO {
     
    private Conexao conexao;
   
    private Connection conn;
    
    
    
    public ProdutoDAO() {
        this.conexao = new Conexao(); 
        this.conn = this.conexao.getConexao(); 
                                               
    }
   
    public void inserir(Produto produto){
        
        String sql = "INSERT INTO Produtos (nome, preco, quantidade, categoria_id) VALUES (?,?,?,?);";
        
        try {
            
            PreparedStatement stmt = this.conn.prepareStatement(sql);
                        
            stmt.setString(1, produto.getNome());
            stmt.setInt(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoria_id().getId());
            
            
            stmt.execute(); 
            
        }catch(SQLException ex){
            System.out.println("Erro ao inserir produto"+ex.getMessage());
        }
        
    }
    
    public Produto consulta(int id){
        
        String sql = "SELECT * FROM Produtos WHERE id = ?;";
          
        try {
                      
            PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Produto p = new Produto();
            
            rs.first();
            p.setId(id);
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getInt("preco"));
            p.setQuantidade(rs.getInt("quantidade"));
           
            
            int idCategoria = rs.getInt("categoria_id");
            CategoriaDAO cDAO = new CategoriaDAO();
            Categoria c = cDAO.consulta(idCategoria);
           
            p.setCategoria_id(c);
            
            return p;
            
        }catch(SQLException ex){
            System.out.println("Erro ao consultar dados do produto"+ex.getMessage());
            return null;
        }
    }
     
    
    public void atualizar(Produto produto){
        
        String sql = "UPDATE Produtos set nome = ?, preco = ?, quantidade = ?, categoria_id = ? WHERE id = ?;";
               
        try {
                       
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            
            stmt.setString(1, produto.getNome());
            stmt.setInt(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoria_id().getId());
            stmt.setInt(5, produto.getId());
            
            stmt.execute();
            
            
        }catch(SQLException ex){
            System.out.println("Erro ao atualizar os dados do produto"+ex.getMessage());
            
        }
    }
    
    
    public void excluir(int id){
        
        try{
            
            String sql = "DELETE FROM Produtos WHERE id = ?;";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            
            
        }catch(SQLException ex){
            System.out.println("Erro ao excluir produto"+ex.getMessage());
            
        }
        
        
    }
    
   public List<Produto> getProdutos(){
       
       String sql = "SELECT * FROM Produtos";
       
       try{
           
           PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
           
           ResultSet rs = stmt.executeQuery();
           List<Produto> listaProdutos = new ArrayList();
           
           while (rs.next()){
               Produto p = new Produto();
               p.setId(rs.getInt("id"));
               p.setNome(rs.getString("nome"));
               p.setPreco(rs.getInt("preco"));
               p.setQuantidade(rs.getInt("quantidade"));
               p.setQuantidade(rs.getInt("categoria_id"));
              
               listaProdutos.add(p);
           }
           return listaProdutos;
           
           
       }catch(SQLException ex){
           System.out.println("Erro ao consultar todos os produtos " + ex.getMessage());
           return null;
       }
       
   }
   
   
   public List<Produto> getProdutosNomeECategoria(String nome, int categoriaId) {
    String sql = "SELECT * FROM Produtos WHERE nome LIKE ? AND categoria_id = ?;";
    
    try {
        PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        stmt.setString(1, "%" + nome + "%");
        stmt.setInt(2, categoriaId);
        ResultSet rs = stmt.executeQuery();
        
        List<Produto> listaProdutos = new ArrayList<>();
        while (rs.next()) {
            Produto p = new Produto();
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getInt("preco"));
            p.setQuantidade(rs.getInt("quantidade"));
            
            CategoriaDAO cDAO = new CategoriaDAO();
            Categoria c = cDAO.consulta(rs.getInt("categoria_id"));
            p.setCategoria_id(c);
            
            listaProdutos.add(p);
        }
        return listaProdutos;
    } catch (SQLException ex) {
        System.out.println("Erro ao consultar produtos: " + ex.getMessage());
        return null;
    }
}
   
public List<Produto> getProdutosNome(String nome) {
    String sql = "SELECT * FROM Produtos WHERE nome LIKE ?;";
    
    try {
        PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        stmt.setString(1, "%" + nome + "%");
        ResultSet rs = stmt.executeQuery();
        
        List<Produto> listaProdutos = new ArrayList<>();
        while (rs.next()) {
            Produto p = new Produto();
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getInt("preco"));
            p.setQuantidade(rs.getInt("quantidade"));
            
            CategoriaDAO cDAO = new CategoriaDAO();
            Categoria c = cDAO.consulta(rs.getInt("categoria_id"));
            p.setCategoria_id(c);
            
            listaProdutos.add(p);
        }
        return listaProdutos;
    } catch (SQLException ex) {
        System.out.println("Erro ao consultar produtos: " + ex.getMessage());
        return null;
    }
}
   

   
   
    
}
            
            
            
        
            
            
        
        
    


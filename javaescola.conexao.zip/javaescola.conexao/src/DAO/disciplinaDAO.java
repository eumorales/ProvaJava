/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Disciplina;
import beans.Aluno;
import beans.Professor;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class disciplinaDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public disciplinaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
     public void inserir(Disciplina disciplina){
        
        String sql = "INSERT INTO disciplina (nome, cargaHoraria, id_professores) VALUES (?,?,?);";
        //O INSERT INTO insere um novo registro na tabela pessoa, 
        //onde os valores para as colunas nome, sexo e idioma serão fornecidos por parâmetros (?,?,?).
        
        try {
            
            // O objeto PreparedStatement permite que você substitua os '?' no SQL com valores reais.
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            
            //Substituição dos Parâmetros:
            //Aqui os parâmetros ? são preenchidos com os valores correspondentes:
            stmt.setString(1, disciplina.getNome()); //O primeiro parâmetro 1 é substituído por pessoa.getNome().
            stmt.setInt(2, disciplina.getCargaHoraria()); //O segundo parâmetro 2 é substituído por pessoa.getSexo().
            stmt.setInt(3, disciplina.getProfessoresid().getId()); //O terceiro parâmetro 3 é substituído por pessoa.getIdioma().
            
            stmt.execute(); //Isso executa o comando SQL, inserindo o registro no banco de dados
            
        }catch(SQLException ex){
            System.out.println("Erro ao inserir Disciplina"+ex.getMessage());
        }
        
    }
     
     public Disciplina consulta(int id){
        
        String sql = "SELECT * FROM disciplina WHERE id = ?;";
        //O INSERT INTO insere um novo registro na tabela pessoa, 
        //onde os valores para as colunas nome, sexo e idioma serão fornecidos por parâmetros (?,?,?).
        
        try {
            
            // O objeto PreparedStatement permite que você substitua os '?' no SQL com valores reais.
            PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Disciplina d = new Disciplina();
            
            rs.first();
            d.setId(id);
            d.setId(rs.getInt("id"));
            d.setNome(rs.getString("nome"));
            d.setCargaHoraria(rs.getInt("cargaHoraria"));
            

            int idProfessores = rs.getInt("id_professores");
            professorDAO pDAO = new professorDAO();
            Professor p = pDAO.consulta(idProfessores);
            d.setProfessoresid(p);
            
            return d;
            
        }catch(SQLException ex){
            System.out.println("Erro ao consultar dados da disciplina"+ex.getMessage());
            return null;
        }
    }
     
    public void atualizar(Disciplina disciplina){
        
        String sql = "UPDATE disciplina set nome = ?, cargaHoraria = ?, id_professores = ? WHERE id = ?;";
        //O INSERT INTO insere um novo registro na tabela pessoa, 
        //onde os valores para as colunas nome, sexo e idioma serão fornecidos por parâmetros (?,?,?).
        
        try {
            
            // O objeto PreparedStatement permite que você substitua os '?' no SQL com valores reais.
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            
            stmt.setString(1, disciplina.getNome());
            stmt.setInt(2, disciplina.getCargaHoraria());
            stmt.setInt(3, disciplina.getProfessoresid().getId());
            stmt.setInt(4, disciplina.getId());
            
            stmt.execute();
            
            
        }catch(SQLException ex){
            System.out.println("Erro ao atualizar os dados da disciplina"+ex.getMessage());
            
        }
    }
    
    
    public void excluir(int id){
        
        try{
            
            String sql = "DELETE FROM disciplina WHERE id = ?;";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            
            
        }catch(SQLException ex){
            System.out.println("Erro ao excluir disciplina: "+ex.getMessage());
            
        }
        
        
    }
    
}

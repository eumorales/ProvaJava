/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author laboratorio
 */
public class Disciplina {
    
    private int id;
    private String nome;
    private int cargaHoraria;
    private Professor professoresid;

    
    public Disciplina(String nome, int cargaHoraria, Professor professoresid) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.professoresid = professoresid;
    }
    
    public Disciplina(){
        
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public Professor getProfessoresid() {
        return professoresid;
    }

    public void setProfessoresid(Professor professoresid) {
        this.professoresid = professoresid;
    }

    

    
    
    
    
}

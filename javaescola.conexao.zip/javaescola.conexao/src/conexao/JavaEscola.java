package conexao;

public class JavaEscola {
    public static void main(String[] args) {
        
        Conexao c = new Conexao();
        c.getConexao();
        
        
    }
}
